simple tests on irs data
